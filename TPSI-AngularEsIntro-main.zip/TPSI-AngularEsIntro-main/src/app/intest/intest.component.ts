import { Component } from '@angular/core';

@Component({
  selector: 'intest',
  templateUrl: './intest.component.html',
  styleUrls: ['./intest.component.css']
})
export class IntestComponent {

}
